/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sh_pipeline_ops.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jnovack <jnovack@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/12 15:08:09 by jnovack           #+#    #+#             */
/*   Updated: 2025/05/19 13:46:39 by jnovack          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* srcs/sh_operators/sh_pipeline_ops.c */
#include "../../includes/minishell.h"

extern int g_shell_exit_status;

/**
 * @brief Fecha todos os descritores de pipe herdados no filho.
 */
void sh_child_cleanup_pipes(t_sh_exec *executor)
{
    t_sh_pipe *p = executor->active_pipes;
    while (p)
    {
        close(p->fds[0]);
        close(p->fds[1]);
        p = p->next;
    }
}

/**
 * @brief Multiplexa execução de comandos simples, operadores lógicos e pipelines.
 */
void sh_execute_command_multiplex(t_sh_node *node,
                                  int *node_fd,
                                  t_sh_exec *executor,
                                  exec_t execution_mode)
{
    pid_t child;

    if (!executor || !node || !node_fd)
        return;

    /* —— comando simples —— */
    if (node->cmd)
    {
        if (execution_mode == EXEC_PIPE)
        {
            child = fork();
            if (child < 0)
                return;
            if (child == 0)
            {
                /* redireciona stdin se necessário e atualiza node_fd */
                if (node_fd[0] != STDIN_FILENO)
                {
                    dup2(node_fd[0], STDIN_FILENO);
                    node_fd[0] = STDIN_FILENO;
                }
                /* redireciona stdout se necessário e atualiza node_fd */
                if (node_fd[1] != STDOUT_FILENO)
                {
                    dup2(node_fd[1], STDOUT_FILENO);
                    node_fd[1] = STDOUT_FILENO;
                }

                sh_child_cleanup_pipes(executor);
                sh_handle_command(node, node_fd, executor, EXEC_PIPE);
                exit(g_shell_exit_status);
            }
            sh_pid_push(&(executor->running_procs), sh_init_pid(child));
        }
        else
        {
            sh_handle_command(node, node_fd, executor, execution_mode);
        }
    }
    /* —— operador lógico —— */
    else if (node->token && (node->token->type & TOKEN_LOGICAL))
    {
        if (!ft_strncmp(node->token->content, "&&", 3))
            sh_or_exec(node, node_fd, executor, execution_mode);
        else
            sh_and_exec(node, node_fd, executor, execution_mode);
    }
    /* —— pipeline —— */
    else
    {
        sh_execute_pipeline(node, node_fd, executor, execution_mode);
    }

    if (errno == EMFILE)
    {
        g_shell_exit_status = 1;
        sh_display_error(ERR_FD_LIMIT, "pipe");
    }
}

/**
 * @brief Executa recursivamente o pipeline (left | right).
 */
void sh_execute_pipeline(t_sh_node *node,
                         int *node_fd,
                         t_sh_exec *executor,
                         exec_t execution_mode)
{
    int        fd[2];
    t_sh_pid  *initial_pid  = NULL;
    t_sh_pipe *initial_pipe = executor->active_pipes;

    if (execution_mode == EXEC_WAIT)
        initial_pid = executor->running_procs;

    /* cria nova pipe */
    sh_pipe_push(&(executor->active_pipes), sh_init_pipe());
    if (executor->active_pipes == initial_pipe ||
        executor->active_pipes->fds[0] < 0 ||
        executor->active_pipes->fds[1] < 0)
        return;

    /* lado esquerdo: in=node_fd[0], out=pipe[1] */
    fd[0] = node_fd[0];
    fd[1] = executor->active_pipes->fds[1];
    sh_execute_command_multiplex(node->left, fd, executor, EXEC_PIPE);
    close(executor->active_pipes->fds[1]);

    /* lado direito: in=pipe[0], out=node_fd[1] */
    fd[0] = executor->active_pipes->fds[0];
    fd[1] = node_fd[1];
    sh_execute_command_multiplex(node->right, fd, executor, EXEC_PIPE);
    close(executor->active_pipes->fds[0]);

    sh_wait_pipeline_processes(initial_pid, executor, execution_mode);
}

/**
 * @brief Aguarda todos os processos do pipeline e fecha a pipe deste estágio.
 */
void sh_wait_pipeline_processes(t_sh_pid *initial_pid,
                                t_sh_exec *executor,
                                exec_t execution_mode)
{
    t_sh_pid *waiting;
    int       status;
    int       first = 1;

    sh_delete_pipe(sh_pipe_pop(&(executor->active_pipes)));

    while (execution_mode == EXEC_WAIT &&
           executor->running_procs != initial_pid)
    {
        waiting = sh_pid_pop(&(executor->running_procs));
        waitpid(waiting->pid, &status, 0);
        sh_process_command_exit(status);
        if (first)
        {
            g_shell_exit_status = WEXITSTATUS(status);
            first = 0;
        }
        free(waiting);
    }
}

/**
 * @brief Executa `&&` no contexto de pipeline ou direto.
 */
void sh_and_exec(t_sh_node *node, int *node_fd, t_sh_exec *ex, exec_t mode)
{
    pid_t child;
    int   err_code = 0;

    if (mode == EXEC_PIPE)
    {
        child = fork();
        if (child == -1)
            return;
        if (child == 0)
        {
            err_code = sh_execute_logical_and(node, node_fd, ex);
            sh_fork_cleanup(ex);
            exit(err_code);
        }
        sh_pid_push(&(ex->running_procs), sh_init_pid(child));
    }
    else
    {
        sh_execute_logical_and(node, node_fd, ex);
    }
}

/**
 * @brief Executa `||` no contexto de pipeline ou direto.
 */
void sh_or_exec(t_sh_node *node, int *node_fd, t_sh_exec *ex, exec_t mode)
{
    pid_t child;
    int   err_code = 0;

    if (mode == EXEC_PIPE)
    {
        child = fork();
        if (child == -1)
            return;
        if (child == 0)
        {
            err_code = sh_execute_logical_or(node, node_fd, ex);
            sh_fork_cleanup(ex);
            exit(err_code);
        }
        sh_pid_push(&(ex->running_procs), sh_init_pid(child));
    }
    else
    {
        sh_execute_logical_or(node, node_fd, ex);
    }
}




