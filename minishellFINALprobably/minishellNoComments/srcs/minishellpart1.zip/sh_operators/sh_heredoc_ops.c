/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sh_heredoc_ops.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jnovack <jnovack@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/05/12 15:07:58 by jnovack           #+#    #+#             */
/*   Updated: 2025/05/13 10:50:11 by jnovack          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/minishell.h"

extern int	g_shell_exit_status;

/**
 * @brief Handles heredoc limit error
 * 
 * Displays error message, cleans up resources, and exits
 * 
 * @param tokens Token list to be cleared
 * @param environment Environment to be cleared
 */
void sh_handle_heredoc_limit(t_sh_token *tokens, t_sh_env **environment)
{
  // display heredoc limit error
  sh_display_error(ERR_HEREDOC_LIMIT, NULL);
  // cleanup resources
  sh_free_token_list(tokens);
  sh_destroy_env_list(*environment);
  //exit whit error status
  exit(ERR_ERRORS);
}

/**
 * @brief Parses and processes a single line of heredoc input
 * 
 * Handles variable expansion and writes line to file
 * 
 * @param line Pointer to input line
 * @param fd Heredoc file descriptor
 * @param expand Flag for variable expansion
 */
void sh_parse_heredoc_line(char **line, int fd, int expand)
{
  static int first_line = 1;  // Initialize only once
  
  if (expand)
    sh_replace_env_vars(sh_env_context(NULL), line, QUOTE_IGNORE);
  
  // Write the line to the file
  write(fd, *line, ft_strlen(*line));
  
  // Add newline after each line (except first time)
  if (!first_line)
    write(fd, "\n", 1);
  first_line = 0;  // Clear flag after first line
  
  free(*line);
  *line = readline(PROMPT_HEREDOC); 
}


/**
 * @brief Processes heredoc input for a single delimiter
 * 
 * Reads input lines until delimiter is found
 * 
 * @param delimiter Heredoc termination string
 * @param temp_file Temporary file path
 * @param fd File descriptor for writing
 * @return Error status
 */
/**
 * @brief Processes heredoc input for a single delimiter
 * 
 * Reads input lines until delimiter is found
 * 
 * @param delimiter Heredoc termination string
 * @param temp_file Temporary file path
 * @param fd File descriptor for writing
 * @return Error status
 */int sh_process_heredoc_line(char *delimiter, char *temp_file, int fd)
{
  char *line;
  int should_expand;
  
  if (fd == -1)
  {
    free(delimiter);
    return(ERR_FAIL_GENERAL);
  }
  
  should_expand = !(ft_strchr(delimiter, '"') || ft_strchr(delimiter, '\''));
  sh_rmv_quotes(&delimiter, QUOTE_NONE);
  
  sh_heredoc_state(temp_file, 0);
  sh_heredoc_state(delimiter, 1);
  sh_heredoc_state((char*)&fd, 2);
  
  line = readline(PROMPT_HEREDOC);
  
  // Simpler loop with exact string comparison
  while (line && strcmp(line, delimiter) != 0 && !access(temp_file, F_OK))
  {
    if (should_expand)
      sh_replace_env_vars(sh_env_context(NULL), &line, QUOTE_IGNORE);
    
    write(fd, line, ft_strlen(line));
    write(fd, "\n", 1);
    
    free(line);
    line = readline(PROMPT_HEREDOC);
  }
  
  free(delimiter);
  free(temp_file);
  
  if (!line)
    return(ERR_FAIL_GENERAL);
  
  free(line);
  return(ERR_NONE);
}

/**
 * @brief Handles heredoc process exit scenarios
 * 
 * Processes different exit codes and manages resources
 * 
 * @param delimiter Heredoc termination string
 * @param temp_file Temporary file path
 * @param exit_status Process exit status
 * @return File descriptor or error code
 */
int sh_handle_heredoc_exit(char *delimiter, char *temp_file, int exit_status)
{
    int fd;
    
    // Extract exit status
    exit_status = WEXITSTATUS(exit_status);
    
    printf("DEBUG: Handling heredoc exit, status = %d\n", exit_status);
    
    // Handle different exit scenarios
    if (exit_status == 1)
    {
        // Remove quotes from delimiter
        sh_rmv_quotes(&delimiter, QUOTE_NONE);
        // Display heredoc stop error
        sh_display_error(ERR_HEREDOC_ABORTED, delimiter);
    }
    else if (exit_status == 130)
    {
        unlink(temp_file);
        free(delimiter);
        free(temp_file);
        // Set global exit value
        g_shell_exit_status = 130;
        return(FILE_HEREDOC_TEMP);
    }
    
    // Open and return fd
    fd = open(temp_file, O_RDONLY);
    printf("DEBUG: Opening heredoc temp file, fd = %d\n", fd);
    
    unlink(temp_file);
    free(delimiter);
    free(temp_file);
    return(fd);
}

/**
 * @brief Creates a heredoc process
 * 
 * Forks a child process to handle heredoc input
 * 
 * @param delimiter Heredoc termination string
 * @param temp_file Temporary file path
 * @return File descriptor or error code
 */
int sh_create_heredoc(char *delimiter, char *temp_file)
{
    pid_t heredoc_pid;
    int fd;
    int error_code;
    
    // Print debug info
    printf("DEBUG: Creating heredoc with delimiter '%s'\n", delimiter);
    
    // Temporarily ignore signals
    sh_configure_signal_state(HANDLER_IGN);
    
    // Create temporary file in parent process to ensure it exists
    fd = open(temp_file, O_CREAT | O_EXCL | O_WRONLY, 0600);
    if (fd == -1) {
        printf("DEBUG: Failed to create heredoc temp file\n");
        free(delimiter);
        free(temp_file);
        return (-1);
    }
    
    // Fork heredoc process
    heredoc_pid = fork();
    if (heredoc_pid == -1) {
        printf("DEBUG: Failed to fork heredoc process\n");
        close(fd);
        unlink(temp_file);
        free(delimiter);
        free(temp_file);
        return (-1);
    }
    
    // Child process
    if (heredoc_pid == 0)
    {
        // Set signal handling
        rl_catch_signals = 1;
        sh_configure_signal_state(HANDLER_HEREDOC);
        
        // Process heredoc
        error_code = sh_process_heredoc_line(delimiter, temp_file, fd);
        
        // Cleanup resources
        sh_destroy_tree(sh_command_tree_state(0, NULL));
        sh_destroy_env_list(sh_env_context(NULL));
        rl_clear_history();
        
        // Close all file descriptors
        close(fd);
        close(STDIN_FILENO);
        close(STDOUT_FILENO);
        close(STDERR_FILENO);
        
        // Exit with error code
        exit(error_code);
    }
    
    // Parent process
    close(fd); // Close parent's copy of the file descriptor
    
    // Wait for child to complete
    waitpid(heredoc_pid, &error_code, 0);
    sh_configure_signal_state(HANDLER_INTERRUPT);
    
    printf("DEBUG: Heredoc child process completed with status %d\n", WEXITSTATUS(error_code));
    
    // Handle result and return file descriptor
    return sh_handle_heredoc_exit(delimiter, temp_file, error_code);
}