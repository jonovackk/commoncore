#include "../includes/libft.h"

int	ft_max(int a, int b)
{
	if (a > b)
		return (a);
	return (b);
}